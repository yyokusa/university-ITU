#pragma once

#include<string>

struct Stack;
struct Queue;
struct MultiQueue;
struct Process;
struct Subtask;


struct Stack
{
    Subtask* head;
    void init();
    void close();
    void push(Subtask* in);
    Subtask* pop();
    bool isEmpty();
    void printAll();
};

struct Queue
{
    Process* head;
    Process* tail;
    void init();
    void close();
    void queue(Process* in);
    Process* dequeue();
    bool isEmpty();
    void printAll();
    Process* front();
};

struct MultiQueue
{
    Queue queues[3];
    int level2_count;
    void init();
    void close();
    void queue(Process* in);
    Process* dequeue(int level);
    bool isEmpty();
    void printAll();
    Process* front(int);
};

struct Process
{
    std::string p_name;
    int arrival_time;
    int deadline;
    int task_count;
    int level;
    Stack p_stack;
    Process* next;
};

struct Subtask
{
    std::string t_name;
    int duration;
    Subtask* next;
};