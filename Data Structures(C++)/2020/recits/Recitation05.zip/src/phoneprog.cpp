#include <iostream> // C++ giri�/��k�� fonksiyonlar� i�in
#include <stdlib.h> // system("cls") fonksiyonu i�in
#include <iomanip>  // cin.ignore(), setw, vb. kullan�mlar i�in
#include <cstring>
#include <time.h> /* time */


#include "listoperations.h" // Kaps�l tan�mlar�

using namespace std; // cin ve cout i�lemlerinin k�sa yaz�m� i�in


typedef List Datastructure; // Kaps�l de�i�keni

Datastructure book;

// Fonksiyon prototip tan�mlar�:
void print_menu();
bool perform_operation(char);
void search_record();
void add_record();
void delete_record();
void update_record();


void test(int);
void randomfill(int);
void randstr(char[], int, int, int);

int main(){	
	book.create();	
	bool end = false; 
	char choice; 	
	while (!end) { 
		print_menu(); 
		cin >> choice;
		end = perform_operation(choice); 
		} 
		
	//srand(clock());
	//randomfill(100000);
	//test(100);
			
	book.close();
	return EXIT_SUCCESS;
}

void print_menu(){
	//system("clear"); 
	cout << endl << endl;
	cout << "PHONE BOOK APPLICATION" << endl;
	cout << "Choose an operation" << endl;
	cout << "S: Record Search" << endl;
	cout << "A: Record Add" << endl;
	cout << "U: Record Update" << endl;
	cout << "D: Record Delete" << endl;	
	cout << "E: Exit" << endl;	
	cout << endl;
	cout << "Enter a choice {S,A,U,D,E}: ";
}

bool perform_operation(char choice){
	bool terminate=false;
	switch (choice) { 
	case 'S': case 's': 
			search_record();
			break; 
		case 'A': case 'a': 
			add_record();
			break; 
		case 'U': case 'u': 
			update_record();
			break;
		case 'D': case 'd': 
			delete_record();
			break;
		case 'E': case 'e': 
			cout << "Are you sure you want to exit the program? (Y/N):";
			cin >> choice;
			if(choice=='Y' || choice=='y')
			{
				terminate=true; 
				break; 
			}
		default: 
			cout << "Error: You have entered an invalid choice" << endl; 
			cout << "Please try again {S, A, U, D, E}  :" ;
			cin >> choice;
			terminate = perform_operation(choice);
			break; 
	}
	return terminate;
}

void search_record(){
	char name[NAME_LENGTH];
	cout << "Please enter the name of the person you want to SEARCH for (press'*'for full list):" << endl;
	cin.ignore(1000, '\n');
	cin.getline(name,NAME_LENGTH);		
	if(book.search(name)==0){
		cout << "Could not find a record matching your search criteria" << endl;
	}
	getchar(); // system("pause") yerine kullan�l�yor.
};

void add_record(){
	Phone_Record newrecord;	
	cout << "Please enter contact information you want to ADD" << endl;
	cout << "Name : " ;	
	cin.ignore(1000, '\n');
	cin.getline(newrecord.name,NAME_LENGTH);
	cout << "Phone number :";
	cin >> setw(PHONENUM_LENGTH) >> newrecord.phonenum;
	book.add(&newrecord);
	cout << "Record added" << endl;
	getchar(); 
};

void delete_record(){
	char name[NAME_LENGTH];
	int choice;	
	cout << "Please enter the name of the person whose record you want to DELETE (press'*'for full 	    list):" << endl;
	cin.ignore(1000, '\n');
	cin.getline(name,NAME_LENGTH);		
	int personcount=book.search(name); 
	if(personcount==0){
		cout << "Could not find a record matching your search criteria" << endl;		
	}
	else {
		if (personcount==1){		
			cout << "Record found." << endl;
			cout << "If you want to delete this record please enter its number (Enter -1 to exit without performing any operations): " ;
		}
		else
			cout << "Enter the number of the record you want to delete (Enter -1 to exit without performing any operations): " ;
		cin >> choice;
		if(choice==-1) return;
		book.remove(choice);	
		cout << "Record deleted." <<endl;
		
	}
	getchar(); 
};

void update_record(){
	char name[NAME_LENGTH];
	int choice;	
	cout << "Please enter the name of the person whose record you want to UPDATE (press'*'for full list):" << endl;
	cin.ignore(1000, '\n');
	cin.getline(name,NAME_LENGTH);		
	int personcount=book.search(name); 
	if(personcount==0){
		cout << "Could not find a record matching your search criteria" << endl;		
	}
	else {
		if (personcount==1){		
			cout << "Record found." << endl;
			cout << "If you want to update this record please enter 			   its number (Enter -1 to exit without performing any operations): " ;
		}
		else
			cout << "Enter the number of the record you want to update (Enter -1 to exit without performing any operations): " ;

		cin >> choice;

		if(choice==-1) return;

		Phone_Record newrecord;
		cout << "Please enter current contact information" << endl;
		cout << "Name : " ;
		cin.ignore(1000, '\n');
		cin.getline(newrecord.name,NAME_LENGTH);
		cout << "Phone number :";
		cin >> setw(PHONENUM_LENGTH) >> newrecord.phonenum;
		book.update(choice,&newrecord);	
		cout << "Record successfully updated." <<endl;		
	}
	getchar(); 
};

void test(int trials)
{

	const short namelen = 6;
	char name[namelen];

	clock_t start = clock();
	for (int i = 0; i < trials; i++)
	{
		randstr(name, namelen, 65, 26);
		book.search(name);
	}

	clock_t end = clock();

	cout << "It took " << (double)(end - start) * 1000 / CLOCKS_PER_SEC << " milliseconds" << endl;

	getchar();
}

void randomfill(int numofrecords)
{

	const short namelen = 6;
	char name[namelen];
	const short phonelen = 8;
	char phone[phonelen];

	for (int i = 0; i < numofrecords; i++)
	{

		randstr(name, namelen, 65, 26);
		randstr(phone, phonelen, 48, 10);

		Phone_Record newrecord;
		strncpy(newrecord.name, name, namelen);
		strncpy(newrecord.phonenum, phone, phonelen);
		book.add(&newrecord);
	}
}

void randstr(char str[], int len, int start, int end)
{

	for (int i = 0; i < len - 1; i++)
		str[i] = ((char)(start + rand() % end));

	str[len - 1] = '\0';
}

