#define NAME_LENGTH 30
#define PHONENUM_LENGTH 15

#define INIT_SIZE 5

struct Phone_Record{
	char* name;	
	char* phonenum;	
};
