# itudb2140

Please follow instructions below to run application:

1 - Navigate into folder with this structure
    README.md db_queries.sql interaktivt.cfg
    db_csv interaktivt progress

2 - Add following to your PATH, change directory path according to where you store the folder
    export FLASK_APP=/Users/yasinyokus/repos/itudb2140/interaktivt
    export INTERAKTIVT_SETTINGS=/Users/yasinyokus/repos/itudb2140/interaktivt.cfg

3 - Type 'flask run' and press enter from the folder with this structure
    README.md db_queries.sql interaktivt.cfg
    db_csv interaktivt progress
