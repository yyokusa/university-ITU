#ifndef FILEOPERATIONS_H
#define FILEOPERATIONS_H
#include <stdio.h>

#define strnicmp strncasecmp

#include "record.h"

struct File{
	char filename[20];
	FILE *phonebook;
	void create();
	void close();
	void add(Phone_Record *);
	int search(char []);
	void remove(int recordnum);
	void update(int recordnum, Phone_Record *);
};
#endif
