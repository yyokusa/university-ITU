#include <iostream>
#include <stdlib.h>

#include "tests.h"

using namespace std;

int main()
{
	//test_traversals();
	test_bfs();

	getchar();
	return EXIT_SUCCESS; 
}




