#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "fileoperations.h"

using namespace std;

void File::add(Phone_Record *nrptr){
	fseek(phonebook, 0, SEEK_END); // Dosya sonuna git. (http://www.cplusplus.com/reference/cstdio/fseek/) SEEK_END: End of the file.
	fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // Dosya sonuna yaz. (http://www.cplusplus.com/reference/cstdio/fwrite/)
}

void File::create(){	
	strcpy(filename,"phonebook.txt");
	phonebook = fopen( filename, "r+" );
	if(!phonebook){ // Dosya bulunamad�, bu nedenle bo� olarak olu�tur.		
		if(!(phonebook = fopen( filename, "w+" ))){
			cerr << "Cannot open file" << endl;
			exit(1);
		}
	}
}

void File::close(){
	fclose(phonebook);
}

int File::search(char *desired){
	Phone_Record k;
	int counter=0;
	bool all=false;
	int found=0;
	if(strcmp(desired,"*")==0)  //Compares the string str1 to the string str2. (http://www.cplusplus.com/reference/cstring/strcmp/?kw=strcmp)
		all=true;
	fseek(phonebook, 0, SEEK_SET); // Dosya ba��na git. SEEK_SET: Beginning of the file.
	while(!feof(phonebook)){		
		counter++;
		fread( &k, sizeof (Phone_Record), 1, phonebook);		
		if(feof(phonebook)) break;

		if(!all && strnicmp(k.name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.

		// "*" verildi�i i�in arama yap�lmayacak, sadece listeleme yap�lacak. 
		cout << counter << "." << k.name << " " << k.phonenum << endl;
		found++;
	}	
	return found;
}

void File::update(int recordnum, Phone_Record *nrptr){
    // Dosyada Kay�tNo ile belirtilen sat�ra git. 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // �zerine yaz
}

void File::remove(int recordnum){
	Phone_Record emptyrecord={"",""};	// Bo� bir kay�t tutana�� haz�rla.

    // Dosynamea Kay�tNo ile belirtilen sat�ra git. 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(&emptyrecord, sizeof(Phone_Record), 1, phonebook); // �nceki kayd�n �zerine yaz.
}

/*
// Remove without empty slots
void File::remove(int recordnum){
	Phone_Record k;

	fseek(phonebook, 0, SEEK_SET);
	FILE *new_phonebook;
	new_phonebook = fopen("tmp.txt", "w+" );
	int i = 1;
	while(!feof(phonebook))
	{
		fread( &k, sizeof (Phone_Record), 1, phonebook);
		if(!feof(phonebook) && i != recordnum)
		{
			fwrite(&k, sizeof(Phone_Record), 1, new_phonebook);
		}
		i++;
	}
	fclose(phonebook);
	fclose(new_phonebook);
	std::remove(filename);
	rename("tmp.txt",filename);
	create();
}
*/

