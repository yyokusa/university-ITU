#ifndef FILEOPERATIONS_H
#define FILEOPERATIONS_H
#include <stdio.h>
#include <fstream>

#define strnicmp strncasecmp


#include "record.h"

struct File{
	char filename[20];
	//Phone_Record records[ARRAY_SIZE]; //*
	Phone_Record* records;
	int size=0;
	std::fstream phonebook;
	void increaseSize();
	int records_count=0; //*
	//FILE *phonebook;
	void create();
	void close();
	void add(Phone_Record *);
	int search(char []);
	void remove(int recordnum);
	void update(int recordnum, Phone_Record *);
};
#endif
