/* Phone Book using Binary Search Tree*/

#include <iostream>
#include <string.h>
#include "tree.h"

using namespace std;

void Tree::create()
{
	root=NULL;
	nodecount = 0;
	read_fromfile();
}

void Tree::close()
{
	write_tofile();
	emptytree(root);
}

void Tree::read_fromfile()
{
	struct File_Record
	{
		char name[NAME_LENGTH];	
   		char phonenum[PHONENUM_LENGTH];
	} record;
	filename = new char[30];
	strcpy(filename,"phonebook.txt"); 
	if (!(phonebook = fopen(filename,"r+")))
	{
		cout<<"Could not open file, so it will work on memory only"<<endl;
		return;
	}
	
	Phone_node *newnode;
	fseek(phonebook,0,SEEK_SET);
	
	
	while(!feof(phonebook))
	{
		newnode = new Phone_node;
		newnode->left = newnode->right = NULL;
		fread(&record,sizeof(File_Record),1,phonebook);
		strcpy(newnode->name,record.name);
		strcpy(newnode->phonenum,record.phonenum);
		add(newnode);
		delete newnode;
	}
	fclose(phonebook);
}

void Tree::add( Phone_node *toadd)
{
	Phone_node *newnode = new Phone_node;
	strcpy(newnode->name,toadd->name);
	strcpy(newnode->phonenum,toadd->phonenum);
	newnode->left = newnode->right = NULL;

	if( root == NULL) // this is first node of tree
	{
		root = newnode;
		nodecount++;
		return;
	}
	Phone_node *traverse = root;
	int comparision;
	while(traverse!=NULL)
	{
		comparision = strcmp(newnode->name,traverse->name);
		if (comparision<0)
		{
			if(traverse->left==NULL)
			{
				traverse->left=newnode;
				nodecount++;
				return;
			}
			else
			{
				traverse=traverse->left;
			}
			
		}
		else if (comparision>0)
		{
			if(traverse->right==NULL)
			{
				traverse->right=newnode;
				nodecount++;
				return;
			}
			else
			{
				traverse=traverse->right;
			}			
		}
		else
		{
			cout<<"Names can not  be dublicated"<<endl;
			return;
			break;
		}		
	}
}

void Tree::write_tofile()
{
	if (!(phonebook = fopen(filename,"w")))
	{
		cerr<<"Could not open file"<<endl;
		return;
	}
	write_preorder(root);
	fclose(phonebook);
}

void Tree::write_preorder(Phone_node *node)
{
	// to get the same tree each node need to come before his ancestors Therefore, PRE-ORDER TRAVERSAL is used.
	struct File_Record
	{
		char name[NAME_LENGTH];	
   		char phonenum[PHONENUM_LENGTH];
	} record;
	if (node)
	{
		strcpy(record.name,node->name);
		strcpy(record.phonenum,node->phonenum);
		fwrite(&record,sizeof(record),1,phonebook);
		write_preorder(node->left);
		write_preorder(node->right);
	}
}

void Tree::emptytree(Phone_node *node)
{
	// to keep BST struct, child or children of a node need to be deleted before the node. Therefore, POST-ORDER TRAVERSAL is used.
	if (node)
	{
		if(node->left!=NULL)
		{
			emptytree(node->left);
			node->left=NULL;
		}
		if(node->right!=NULL)
		{
			emptytree(node->right);
			node->right=NULL;
		}
		delete node;
	}
}

int Tree::search(char *target_name)
{
	Phone_node *traverse = root;
	int countfound=0;
	bool all = false;
	if(strcmp(target_name,"*")==0)
		all = true;
	if(all)
	{
		traverse_inorder(root);
		countfound++;
	}
	else
	{
		int comparision;
		while(traverse)
		{
			comparision = strcmp(target_name,traverse->name);
			if (comparision<0)
			{
				traverse=traverse->left;				
			}
			else if (comparision>0)
			{
				traverse=traverse->right;
			}
			else
			{
				cout<<traverse->name<<" "<<traverse->phonenum<<endl;
				countfound++;
				break;
			}		
		}
	}	
	return countfound;
}

void Tree::traverse_inorder(Phone_node *node)
{
	if(node)
	{
		traverse_inorder(node->left);
		cout<<node->name<<" "<<node->phonenum<<endl;
		traverse_inorder(node->right);
	}
}

void Tree::remove(char *target_name)
{
	Phone_node *traverse, *parent;
	traverse = root;
	char direction = 'K';
	int comparision;
	while (traverse)
	{
		comparision = strcmp(target_name,traverse->name);
		if (comparision < 0)
		{
			parent = traverse;
			traverse = traverse->left;
			direction = 'L';
		}
		else if(comparision > 0)
		{
			parent = traverse;
			traverse = traverse->right;
			direction = 'R';
		}
		else
		{
			//*
			if (traverse->left==NULL && traverse->right==NULL) 	// removing a leaf node
			{
				//	step 1 : disconnect the target with its parent
				//	step 2 : delete target
				
				switch (direction)
				{
				case 'L':
					parent->left=NULL;
					break;
				case 'R':
					parent->right=NULL;
					break;
				default:
					root=NULL;
					break;
				}
				delete traverse;
				nodecount--;
				return;
			}
			else if (traverse->right==NULL) 					// removing a node that has only left child
			{
				//	step 1 : connect the parent of target with the left sub-tree of target
				//	step 2 : delete target
				
				switch (direction)
				{
				case 'L':
					parent->left=traverse->left;
					break;
				case 'R':
					parent->right=traverse->left;
					break;
				default:
					root=traverse->left;
					break;
				}
				delete traverse;
				nodecount--;
				return;
			}
			else if(traverse->left==NULL)						// removing a node that has only right child
			{
				//	step 1 : connect the parent of target with the right sub-tree of target
				//	step 2 : delete target
				
				switch (direction)
				{
				case 'L':
					parent->left=traverse->right;
					break;
				case 'R':
					parent->right=traverse->right;
					break;
				default:
					root=traverse->right;
					break;
				}
				delete traverse;
				nodecount--;
				return;
			}
			else												// removing a node that has both children
			{
				// 	step 1 : find successor of the target node that you want delete in-order traversal
				//	step 2 : connect the left pointer of successor with the left pointer of target
				//	step 3 : connect the parent of target with the right sub-tree of target
				//	step 4 : delete the target
				
				Phone_node *min_bigger_than_target=traverse->right;
				while (min_bigger_than_target->left)
				{
					min_bigger_than_target=min_bigger_than_target->left;
				}
				min_bigger_than_target->left=traverse->left;
				switch (direction)
				{
				case 'L':
					parent->left=traverse->right;
					break;
				case 'R':
					parent->right=traverse->right;
					break;
				default:
					root=traverse->right;
					break;
				}
				delete traverse;
				nodecount--;
				return;				
			}
			/**/
			/*
			//ALTERNATIVE WAY
			switch (direction)
			{
			case 'L':
				remove(&parent->left);
				break;
			case 'R':
				remove(&parent->right);
				break;
			default:
				remove(&root);
				break;
			}
			return;	
			/
			**/		
		}
	}
	cout<<"Could not find record to remove"<<endl;
}

void Tree::remove(Phone_node **pointer_of_target)
{
	Phone_node *traverse;
	traverse = *pointer_of_target;
	if (traverse==NULL) // attemp to delete non existing node
		return;
	else if (traverse->right == NULL) // attemp to delete a node that has only left child
	{
		*pointer_of_target = traverse->left; // put the the root of left subtree of target instead of target to connect the parent of target with left subtree of target
		delete traverse;
		nodecount--;
	}
	else if (traverse->left == NULL) // attemp to delete a node that has only right child
	{
		*pointer_of_target = traverse->right; // put the the root of right sub-tree of target instead of target to connect the parent of target with right sub-tree of target
		delete traverse;
		nodecount--;
	}
	else 							// atemp to delete a node that has two childeren or has no child
	{
		Phone_node *q;
		for(q= traverse->right; q->left; q=q->left); // find the in-order successor
		q->left = traverse->left;  // connect the left pointer of successor with the left pointer of target
		*pointer_of_target = traverse->right; // put the the root of right subtree of target instead of target to connect the parent of target with right subtree of target
		delete traverse;
		nodecount--;
	}	
}

int Tree::get_root_distance(Phone_node *node)
{
	int distance=0;
	Phone_node *traverse = root;
	int comparision;
	while (traverse)
	{
		comparision=strcmp(node->name,traverse->name);
		if (comparision < 0)
			traverse = traverse->left;
		else if (comparision > 0)
			traverse = traverse->right;
		else
		{
			return distance;
		}
		distance++;
	}
	return -1;
}
void Tree::draw_tree(Phone_node *traverse)
{
	if(traverse)
	{		
		draw_tree(traverse->right);
		for(int i=0;i<get_root_distance(traverse);i++)
			cout<<"\t";
		cout<<"-> "<<traverse->name<<" ["<<get_root_distance(traverse)<<"]"<<endl;
		for(int i=0;i<get_root_distance(traverse);i++)
			cout<<"\t";
		cout<<""<<endl;
		draw_tree(traverse->left);
	}
}