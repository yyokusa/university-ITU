/*
The error lines were made in recitation 3 as in below.

It was not added +1 space for strings for allocation in some lines therefore we got errors. The lines are:
line			old version														new version
91				temp[i].name = new char[strlen(records[i].name)]; 				temp[i].name = new char[strlen(records[i].name)+1]; 
94				temp[i].phonenum = new char[strlen(records[i].phonenum)];		temp[i].phonenum = new char[strlen(records[i].phonenum)+1];

I forgot to close the phonebook file in line 101. I add it(phonebook.close()).

When I wrote the records array to file in close function, I forgot to space(" ") between records name and phonenum.
line 			old version														  new version
140				phonebook<<records[i].name<<""<<records[i].phonenum<<endl;        phonebook<<records[i].name<<" "<<records[i].phonenum<<endl;

"void File::update"(line 182) function had some errors. It is corrected.
*/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "fileoperations.h"

using namespace std;

void File::add(Phone_Record *nrptr){
	/*
	fseek(phonebook, 0, SEEK_END); // Dosya sonuna git. (http://www.cplusplus.com/reference/cstdio/fseek/) SEEK_END: End of the file.
	fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // Dosya sonuna yaz. (http://www.cplusplus.com/reference/cstdio/fwrite/)
	*/
	/*strcpy(records[records_count].name,nrptr->name);
	strcpy(records[records_count].phonenum, nrptr->phonenum);
	records_count++;*/
	if(records_count == size)
	{
		increaseSize();
	}
		records[records_count].name = new char[strlen(nrptr->name)+1];
		strcpy(records[records_count].name, nrptr->name);
		records[records_count].phonenum = new char[strlen(nrptr->phonenum)+1];
		strcpy(records[records_count].phonenum, nrptr->phonenum);
	records_count++;
	
}

void File::create(){	
	/*Phone_Record k;	
	strcpy(filename,"phonebook.txt");
	phonebook = fopen( filename, "r+" );
	if(!phonebook){ // Dosya bulunamad�, bu nedenle bo� olarak olu�tur.		
		if(!(phonebook = fopen( filename, "w+" ))){
			cerr << "Cannot open file" << endl;
			exit(1);
		}
	}
	else{
		int counter=0;
		fseek(phonebook,0,SEEK_SET);
		while(!feof(phonebook)){
			fread(&k,sizeof(Phone_Record),1,phonebook);
			if (strcpy(records[counter].name,k.name) && strcpy(records[counter].phonenum,k.phonenum))
				counter++;
		}
		records_count=counter;
	}
	fclose(phonebook);*/
	records = new Phone_Record[INIT_SIZE];
	size = INIT_SIZE;
	strcpy(filename,"phonebook.txt");
	phonebook.open(filename, fstream::in|fstream::binary);
	if(!phonebook.is_open())
	{
		phonebook.open(filename,fstream::out|fstream::binary);
		if(!phonebook.is_open())
		{
			cerr << "Cannot open file";
			exit(1);
		}
	}
	else
	{
		char temp_name[NAME_LENGTH];
		char temp_phonenum[PHONENUM_LENGTH];

		phonebook>>temp_name>>temp_phonenum;
		while(!phonebook.eof())
		{
			if(records_count==size)
				increaseSize();

			records[records_count].name = new char[strlen(temp_name)+1];
			strcpy(records[records_count].name, temp_name);
			
			records[records_count].phonenum = new char[strlen(temp_phonenum)+1];
			strcpy(records[records_count].phonenum, temp_phonenum);
			records_count++;
			phonebook>>temp_name>>temp_phonenum;
		}
		
	}
	phonebook.close();
}

void File::increaseSize()
{
	size = size*2;
	Phone_Record* temp = new Phone_Record[size];

	for(int i=0;i<records_count;i++)
	{
		temp[i].name = new char[strlen(records[i].name)+1]; //'\0'
		strcpy(temp[i].name, records[i].name);
		delete [] records[i].name;

		temp[i].phonenum = new char[strlen(records[i].phonenum)+1]; //'\0'
		strcpy(temp[i].phonenum, records[i].phonenum);
		delete [] records[i].phonenum;
	}
	delete [] records;
	records = temp;

}

void File::close(){
	/*if(!(phonebook=fopen(filename,"w"))){
		cerr << "Cannot open file" << endl;
		exit(1);
	}
	for (int i=0;i<records_count;i++)
		fwrite(&records[i],sizeof(Phone_Record),1,phonebook);
	fclose(phonebook);*/
	phonebook.open(filename,fstream::out|fstream::binary);
	if(!phonebook.is_open())
	{
		cerr << "Cannot open file" <<endl;
		exit(1);
	}
	for (int i=0;i<records_count;i++)
	{
		phonebook<<records[i].name<<" "<<records[i].phonenum<<endl;

	}
	phonebook.close();

	for(int i=0;i<records_count;i++)
	{
		delete [] records[i].name;
		delete [] records[i].phonenum;
	}
	delete [] records;
}

int File::search(char *desired){
	bool all=false;
	int found=0;
	if(strcmp(desired,"*")==0)  //Compares the string str1 to the string str2. (http://www.cplusplus.com/reference/cstring/strcmp/?kw=strcmp)
		all=true;
	/*
	fseek(phonebook, 0, SEEK_SET); // Dosya ba��na git. SEEK_SET: Beginning of the file.
	while(!feof(phonebook)){		
		counter++;
		fread( &k, sizeof (Phone_Record), 1, phonebook);		
		if(feof(phonebook)) break;

		if(!all && strnicmp(k.name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.

		// "*" verildi�i i�in arama yap�lmayacak, sadece listeleme yap�lacak. 
		cout << counter << "." << k.name << " " << k.phonenum << endl;
		found++;
	}
	*/
	for(int i=0;i<records_count;i++){
		if(!all && strnicmp(records[i].name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.
		cout << i << "." << records[i].name << " " << records[i].phonenum << endl;
		found++;	
	}	
	return found;
}

void File::update(int recordnum, Phone_Record *nrptr){
    	// Dosyada Kay�tNo ile belirtilen sat�ra git.
    	/* 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // �zerine yaz
	*/
	delete [] records[recordnum].name;
	records[recordnum].name = new char[strlen(nrptr->name)+1];
	strcpy(records[recordnum].name, nrptr->name);

	delete [] records[recordnum].phonenum;
	records[recordnum].phonenum = new char[strlen(nrptr->phonenum)+1];
	strcpy(records[recordnum].phonenum, nrptr->phonenum);
}

void File::remove(int recordnum){
	/*
	Phone_Record emptyrecord={"",""};	// Bo� bir kay�t tutana�� haz�rla.

    // Dosynamea Kay�tNo ile belirtilen sat�ra git. 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(&emptyrecord, sizeof(Phone_Record), 1, phonebook); // �nceki kayd�n �zerine yaz.

	*/
	delete [] records[recordnum].name;
	delete [] records[recordnum].phonenum;

	for (;recordnum<records_count;recordnum++){		
		if(recordnum+1<size)
			records[recordnum]=records[recordnum+1];
	}
	records_count--;
}

/*
 [4 5 6 3 7 8] 
 	after removing
 [4 5 3 7 8] // we need to do sliding
*/
/*
// Remove without empty slots
void File::remove(int recordnum){
	Phone_Record k;

	fseek(phonebook, 0, SEEK_SET);
	FILE *new_phonebook;
	new_phonebook = fopen("tmp.txt", "w+" );
	int i = 1;
	while(!feof(phonebook))
	{
		fread( &k, sizeof (Phone_Record), 1, phonebook);
		if(!feof(phonebook) && i != recordnum)
		{
			fwrite(&k, sizeof(Phone_Record), 1, new_phonebook);
		}
		i++;
	}
	fclose(phonebook);
	fclose(new_phonebook);
	std::remove(filename);
	rename("tmp.txt",filename);
	create();
}
*/

