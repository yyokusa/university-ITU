struct resistor
{
    char group;
    double value;
    int quantity;
    resistor *next;
};
