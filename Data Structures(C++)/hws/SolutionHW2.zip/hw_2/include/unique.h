struct unique
{
    double value;
    unique* next;
};