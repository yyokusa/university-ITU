#ifndef _H
#define _H
#include <stdio.h>
#include <iterator> 
#include <map> 
#include <string.h> 

#define DIGIT_SIZE 4

using namespace std;

struct Counter{
    map<string, int> token_map;
	void read_and_count();
	map<string,int> get_most_common_three();   
	bool contains(char *,char);
};
#endif