
class CountryModel:
    def __init__(self, name, hdi_rank, country_id=None):
        self.name = name
        self.hdi_rank = hdi_rank
        self.id = country_id
