#include <iostream>
#include <time.h>

using namespace std;

int binarysum(int A[],int s,int n)
{   
    if(n==1)
        return A[s];
    else
    {
        return binarysum(A,s,n/2) + binarysum(A,s+(n/2),n-(n/2));
    }
     
}

/*
BinarySum(A, 4, 5);
	BinarySum(A, 4, 2) 				            + 	BinarySum(A, 6, 3);
	BinarySum(A, 4, 1)	+ BinarySum(A, 5, 1)	+	BinarySum(A, 6, 1) 	+ BinarySum(A, 7, 2)
		        4		+ 	            5		+		6		        + BinarySum(A, 7, 1) 	+ BinarySum(A, 8, 1)
											                                        7   		+	        8
*/


int main()
{   
    // in this study; recursive summation of sequential integers 
    int N=1000;
    int array[N];

    long t0,t1;

    // initialize array
    for(int i=0;i<N;i++)
        array[i]=i;

    int start_index=4, length=500;
    int sum=0;
    // iterative sum
    t0=clock();
    for (int i=start_index;i<length+start_index;i++)
        sum +=array[i];
    t1=clock();
    cout<<"iterative summation result :"<<sum<<" in "<<float(t1-t0)/CLOCKS_PER_SEC*1000<<" miliseconds"<<endl;    
    // recursive sum
    t0=clock();
    sum=binarysum(array,start_index,length);
    t1=clock();
    cout<<"recursive summation result :"<<sum<<" in "<<float(t1-t0)/CLOCKS_PER_SEC*1000<<" miliseconds"<<endl; 
    return 0;
}
