#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "fileoperations.h"

using namespace std;

void File::add(Phone_Record *nrptr){
	/*
	fseek(phonebook, 0, SEEK_END); // Dosya sonuna git. (http://www.cplusplus.com/reference/cstdio/fseek/) SEEK_END: End of the file.
	fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // Dosya sonuna yaz. (http://www.cplusplus.com/reference/cstdio/fwrite/)
	*/
	strcpy(records[records_count].name,nrptr->name);
	strcpy(records[records_count].phonenum, nrptr->phonenum);
	records_count++;
}


void File::create(){	
	Phone_Record k;	
	strcpy(filename,"phonebook.txt");
	phonebook = fopen( filename, "r+" );
	if(!phonebook){ // Dosya bulunamad�, bu nedenle bo� olarak olu�tur.		
		if(!(phonebook = fopen( filename, "w+" ))){
			cerr << "Cannot open file" << endl;
			exit(1);
		}
	}
	else{
		int counter=0;
		fseek(phonebook,0,SEEK_SET);
		while(!feof(phonebook)){
			fread(&k,sizeof(Phone_Record),1,phonebook);
			if (strcpy(records[counter].name,k.name) && strcpy(records[counter].phonenum,k.phonenum))
				counter++;
		}
		records_count=counter;
	}
	fclose(phonebook);
}

void File::close(){
	if(!(phonebook=fopen(filename,"w"))){
		cerr << "Cannot open file" << endl;
		exit(1);
	}
	for (int i=0;i<records_count;i++)
		fwrite(&records[i],sizeof(Phone_Record),1,phonebook);
	fclose(phonebook);
}

int File::search(char *desired){
	bool all=false;
	int found=0;
	if(strcmp(desired,"*")==0)  //Compares the string str1 to the string str2. (http://www.cplusplus.com/reference/cstring/strcmp/?kw=strcmp)
		all=true;
	/*
	fseek(phonebook, 0, SEEK_SET); // Dosya ba��na git. SEEK_SET: Beginning of the file.
	while(!feof(phonebook)){		
		counter++;
		fread( &k, sizeof (Phone_Record), 1, phonebook);		
		if(feof(phonebook)) break;

		if(!all && strnicmp(k.name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.

		// "*" verildi�i i�in arama yap�lmayacak, sadece listeleme yap�lacak. 
		cout << counter << "." << k.name << " " << k.phonenum << endl;
		found++;
	}
	*/
	for(int i=0;i<records_count;i++){
		if(!all && strnicmp(records[i].name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.
		cout << i << "." << records[i].name << " " << records[i].phonenum << endl;
		found++;	
	}	
	return found;
}

void File::update(int recordnum, Phone_Record *nrptr){
    	// Dosyada Kay�tNo ile belirtilen sat�ra git.
    	/* 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(nrptr, sizeof(Phone_Record), 1, phonebook); // �zerine yaz
	*/
	strcpy(records[recordnum].name,nrptr->name);
	strcpy(records[recordnum].phonenum, nrptr->phonenum);
}

void File::remove(int recordnum){
	/*
	Phone_Record emptyrecord={"",""};	// Bo� bir kay�t tutana�� haz�rla.

    // Dosynamea Kay�tNo ile belirtilen sat�ra git. 
	if(fseek(phonebook, sizeof(Phone_Record)*(recordnum-1), SEEK_SET)==0)
		fwrite(&emptyrecord, sizeof(Phone_Record), 1, phonebook); // �nceki kayd�n �zerine yaz.

	*/
	for (;recordnum<records_count;recordnum++){		
		if(recordnum+1<ARRAY_SIZE)
			records[recordnum]=records[recordnum+1];
	}
	records_count--;
}

/*
 [4 5 6 3 7 8] 
 	after removing
 [4 5 3 7 8] // we need to do sliding
*/
/*
// Remove without empty slots
void File::remove(int recordnum){
	Phone_Record k;

	fseek(phonebook, 0, SEEK_SET);
	FILE *new_phonebook;
	new_phonebook = fopen("tmp.txt", "w+" );
	int i = 1;
	while(!feof(phonebook))
	{
		fread( &k, sizeof (Phone_Record), 1, phonebook);
		if(!feof(phonebook) && i != recordnum)
		{
			fwrite(&k, sizeof(Phone_Record), 1, new_phonebook);
		}
		i++;
	}
	fclose(phonebook);
	fclose(new_phonebook);
	std::remove(filename);
	rename("tmp.txt",filename);
	create();
}
*/

