/*
YOU HAVE TO WRITE THE REQUIRED  FUNCTIONS. YOU CAN ADD NEW FUNCTIONS IF YOU NEED.
*/
#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "counter.h"

using namespace std;

bool Counter::contains(char *token, char target){
	for(int i=0;i<DIGIT_SIZE;i++)
		if (token[i]==target)
			return true;
	return false;
}


void Counter::read_and_count(){		
	int offset=0;
	int index=0;
	char k[DIGIT_SIZE];
	
	FILE *phonebook;
	phonebook = fopen("pi_approximate", "r" );
	if(!phonebook){ 	
		cerr << "Cannot open file" << endl;
		exit(1);
	}
	else{
		fseek(phonebook, 1, SEEK_SET); 
		while(fread(&k, sizeof(k), 1, phonebook)){
			offset++;
			fseek(phonebook, offset, SEEK_SET);
            if(!contains(k,'\n') && !contains(k,'.'))
                token_map[k]++;
		}	
	}
	fclose(phonebook);
}


map<string,int> Counter::get_most_common_three(){ 
    multimap <int, string> reverse_token_map;
    static map <string,int> most_common;

    for (map <string,int>::iterator itr = token_map.begin(); itr != token_map.end(); ++itr) 
    { 
        reverse_token_map.insert(make_pair(itr->second,itr->first));
        //cout << '\t' << itr->first << '\t' << itr->second << '\n'; 
    }
    
    int count=0;
    for (multimap <int,string>::reverse_iterator itr = reverse_token_map.rbegin();count<3;itr++,count++)
    {
        most_common[itr->second]=itr->first;
    }
    return most_common;
}