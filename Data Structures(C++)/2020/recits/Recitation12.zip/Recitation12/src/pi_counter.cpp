#include <iostream> // C++ giriş çıkış fonksiyonları için
#include <stdlib.h> // system("cls") fonksiyonu için
#include <iomanip>  // cin.ignore(), setw, vb. kullanımlar için
#include <string.h>
#include "counter.h"


using namespace std; // cin ve cout iþlemlerinin kýsa yazýmý için

Counter counter;

void print_menu();
bool perform_operation(char);
void initialize();
void display();
void display_most_common_three();

int main(int argc, char* argv[]){
	system("clear");// make this line as comment if you are compiling on Windows
	//system("cls"); // make this line as comment if you are compiling on Linux or Mac 
	counter.read_and_count();
	bool end = false; 
	char choice; 	
	while (!end) { 
		print_menu(); 
		cin >> choice;
		end = perform_operation(choice); 
		}

	return EXIT_SUCCESS;
}

void display(){
	char target[DIGIT_SIZE];
	cout << "Please enter the token that you want to see how many times it is encountered in decimal part in pi number (press'*'for full list)" << endl;
	cout << "Token : ";
	cin >> setw(DIGIT_SIZE+1) >> target;	
	if(strcmp(target,"*")==0){
		for (map <string,int>::iterator itr = counter.token_map.begin(); itr != counter.token_map.end(); ++itr) 
        { 
            cout << '\t' << itr->first << '\t' << itr->second << '\n'; 
        }
        cout<<"There are "<<counter.token_map.size()<<" unique tokens."<<endl;
	}
	else{
		
		if(counter.token_map.count(target)==0)
			cout<<"There is no '"<<target<<"' token in decimal part of PI"<<endl;
		else
			cout<<target<<" "<< counter.token_map.at(target)<<endl;
	}
	getchar(); // system("pause") yerine kullanýlýyor.
}

void display_most_common_three(){
	map<string,int> most_common = counter.get_most_common_three();
	cout<<"The most common three tokens;"<<endl;
	for (map <string,int>::iterator itr = most_common.begin(); itr != most_common.end(); ++itr) 
    { 
        cout << '\t' << itr->first << '\t' << itr->second << '\n'; 
    }
}

void print_menu(){
	cout << endl << endl;
	cout << "COUNTER APPLICATION OF PI'S DECIMAL" << endl;
	cout << "Choose an operation" << endl;
	cout << "D: Display" << endl;
	cout << "M: Print Most Common Three" << endl;
	cout << "E: Exit" << endl;	
	cout << endl;
	cout << "Enter a choice {D,M,E}: ";
}
bool perform_operation(char choice){
	bool terminate=false;
	switch (choice) {
		case 'D': case 'd': 
			display();
			break;		 
		case 'M': case 'm': 
			display_most_common_three();
			break;		

		case 'E': case 'e': 
			cout << "Are you sure you want to exit the program? (Y/N):";
			cin >> choice;
			if(choice=='Y' || choice=='y')
				terminate=true; 
			break; 
		default: 
			cout << "Error: You have entered an invalid choice" << endl; 
			cout << "Please try again {D,M,E}  :" ;
			cin >> choice;
			terminate = perform_operation(choice);
			break; 
	}
	return terminate;
}