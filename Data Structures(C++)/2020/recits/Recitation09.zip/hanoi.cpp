#include <iostream>

using namespace std;


int counter=0;

void move(int source, int target, int N, int tmp)
{
	if(N==1)
		cout<< "("<<++counter<<". step) from "<<source<<". tower to "<<target<<". tower"<<endl;
	else
	{
		move(source,tmp,N-1,target);
		cout<< "("<<++counter<<". step) from "<<source<<". tower to "<<target<<". tower"<<endl;
		move(tmp,target,N-1,source);
	}
	
}


int main()
{
    int N;
	cout<<"RECURSIVE HANOI TOWERS"<<endl;
	cout<<"Please enter the disk count : ";
	cin>>N;

	cout<<"Source Tower# : 1 / Target Tower# 3"<<endl;
	move(1,3,N,2);

    return 0;
}

/*
move(1,3,3,2)  //1 den 3 e taşı
	move(1,2,2,3) //1 den 2 ye taşı
		move(1,3,1,2)
			1.ADIM 1.kuleden 3.kuleye
		2.ADIM 1.kuleden 2.kuleye
		move(3,2,1,1)
			3.ADIM 3.kuleden 2.kuleye
	4.ADIM 1.kuleden 3.kuleye
	move(2,3,2,1) //2 den 3 e taşı
		move(2,1,1,3)
			5.ADIM 2.kuleden 1.kuleye
		6.ADIM 2.kuleden 3.kuleye
		move(1,3,1,2)
			7.ADIM 1.kuleden 3.kuleye	 
*/

