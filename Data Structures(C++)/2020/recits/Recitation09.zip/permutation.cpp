#include <iostream>
#include <string.h>

using namespace std;

void swap(int &a,int &b)
{
    int temp=a;
    a=b;
    b=temp;
}
int counter=0;

void perm(char *list,int k, int m)
{
    if (k==m)
    {
        for (int i=0;i<=m;i++)
            cout<<list[i]<<" ";
        cout<<" counter="<<++counter<<endl;
    }
    else
    {
        for(int i=k;i<=m;i++)
        {
            swap(list[k],list[i]);
            //cout<<"call perm('"<<list<<"',"<<k+1<<","<<m<<")"<<endl; 
            perm(list,k+1,m);
            swap(list[k],list[i]);
        }
    }
    
}


int main()
{
    char list[20]="ABC";
    perm(list,0,strlen(list)-1);
    return 0;
}
/*
perm("ABC",0,2)
	i=0, k=0
	perm("ABC",1,2)
		i=1, k=1
		perm("ABC",2,2)
			ABC sayac 1
		i=2, k=1
		perm("ACB",2,2)
			ACB sayac 2
	i=1, k=0
	perm("BAC",1,2)
		i=1, k=1
		perm("BAC",2,2)
			BAC sayac 3
		i=2, k=1
		perm("BCA",2,2)
			BCA sayac 4
	i=2, k=0
	perm("CBA",1,2)
		i=1, k=1
		perm("CBA",2,2)
			CBA sayac 5
		i=2, k=1
		perm("CAB",2,2)
			CAB sayac 6
*/

