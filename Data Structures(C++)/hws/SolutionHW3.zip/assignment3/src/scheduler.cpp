#include <fstream>
#include <iostream>
#include <stdlib.h>

#include "data_structs.h"

bool getFutureTasks(std::string f_path, Queue* f_tasks)
{
    std::fstream file;
    file.open(f_path,std::fstream::in);
    Process* p;
    Subtask* t;
    while(!file.eof())
    {
        p = new Process;
        p->p_stack.init();
        p->next = NULL;
        file>>p->p_name>>p->level;
        file>>p->arrival_time>>p->task_count;
        p->deadline = p->arrival_time;
        for(int i=0;i<p->task_count;i++)
        {
            t = new Subtask;
            t->next =NULL;
            file>>t->t_name>>t->duration;
            p->deadline += t->duration;
            p->p_stack.push(t);
        }
        f_tasks->queue(p);
    }
    return true;
}

void schedule(Queue* f_tasks)
{
    MultiQueue m_queue;
    Process *next_coming;
    Process* current = NULL;
    Subtask* s_task;
    m_queue.init();
    int t = 0;
    int lateness = 0;
    next_coming = f_tasks->dequeue();
    bool levels_empty = true;
    while(!f_tasks->isEmpty() || !m_queue.isEmpty() || next_coming!=NULL || !levels_empty)
    {
        while(next_coming!=NULL && next_coming->arrival_time<=t)
        {
            m_queue.queue(next_coming);
            next_coming = f_tasks->dequeue();
        }
        if(m_queue.front(0)!=NULL)
        {
            current = m_queue.front(0);
        }
        else if(m_queue.front(1)!=NULL && m_queue.level2_count<2)
        {
            current = m_queue.front(1);
            m_queue.level2_count++;
        }
        else
        {
            current = m_queue.front(2);
            m_queue.level2_count = 0;
        }
            
        if(current!=NULL)
        {
            s_task = current->p_stack.pop();
            std::cout<<current->p_name<<" "<<s_task->t_name<<std::endl;
            t += s_task->duration;
            delete s_task;
            if (current->p_stack.isEmpty())
            {
                lateness += (t-current->deadline);
                //std::cout<<"t = "<<t<<" deadline was = "<<current->deadline<<std::endl;
                m_queue.dequeue(current->level);
                delete current;
                current = NULL;
            }
        }
        else
        {
            t = next_coming->arrival_time;
        }
        levels_empty=m_queue.front(0)==NULL && m_queue.front(1)==NULL && m_queue.front(2)==NULL;
        
        
    }
    //std::cout<<"Scheduled with "<<lateness<<" lateness"<<std::endl;
    std::cout<<"Cumulative Lateness: "<<lateness<<std::endl;
}

int main(int argc, char** argv)
{
    Queue future_tasks;
    future_tasks.init();
    std::string file_path =  "data/data.txt";//argv[1];
    if(getFutureTasks(file_path,&future_tasks))
        schedule(&future_tasks);
    future_tasks.close();

    system("PAUSE");
    return EXIT_SUCCESS;
}

