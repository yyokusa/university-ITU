#include <iostream>
#include "data_structs.h"

void Stack::init()
{
    head = NULL;
}
void Stack::close()
{
    Subtask* traverse;
    traverse = head;
    while(traverse!=NULL)
    {
        head = head->next;
        delete traverse;
        traverse = head;
    }
}
void Stack::push(Subtask* in)
{
    in->next = head;
    head = in;
}
Subtask* Stack::pop()
{
    Subtask* traverse;
    traverse = head;
    if(head!=NULL && head->next!=NULL)
    {
        head = head->next;
        traverse->next = NULL;
    }
    else
    {
        head = NULL;
    }
    return traverse;

}
bool Stack::isEmpty()
{
    return head==NULL;
}
void Stack::printAll()
{
    Subtask* traverse;
    traverse = head;
    while(traverse!=NULL)
    {
        std::cout<<traverse->t_name<<" "<<traverse->duration<<std::endl;
        traverse = traverse->next;
    }
}


void Queue::init()
{
    head=NULL;
    tail=NULL;
}
void Queue::close()
{
    tail=NULL;
    Process* traverse;
    traverse = head;
    while(traverse!=NULL)
    {
        head = head->next;
        traverse->p_stack.close();
        delete traverse;
        traverse = head;
    }
}
void Queue::queue(Process* in)
{
    if(head==NULL)
    {
        head = in;
        tail = in;
    }
    else
    {
        tail->next = in;
        tail = in;
    }
}
Process* Queue::dequeue()
{
    Process* traverse;
    traverse = head;
    if(traverse!=NULL)
    {
        head = head->next;
        if(head==NULL)
            tail = NULL;
        traverse->next = NULL;
    }
    return traverse;
}
bool Queue::isEmpty()
{
    return tail == NULL;
}
void Queue::printAll()
{
    Process* traverse;
    traverse = head;
    while(traverse!=NULL)
    {
        std::cout<<traverse->p_name<<" "<<traverse->level<<std::endl;
        std::cout<<traverse->arrival_time<<" "<<traverse->deadline<<std::endl;
        traverse->p_stack.printAll();
        traverse = traverse->next;
    }
}
Process* Queue::front()
{
    return head;
}

void MultiQueue::init()
{
    level2_count = 0;
    for (int i=0;i<3;i++)
    {
        queues[i].init();
    }
}
void MultiQueue::close()
{
    for (int i=0;i<3;i++)
    {
        queues[i].close();
    }
}
void MultiQueue::printAll()
{
    for (int i=0;i<3;i++)
    {
        std::cout<<"Level "<<i+1<<std::endl;
        queues[i].printAll();
    }
}

void MultiQueue::queue(Process* in)
{
    queues[in->level-1].queue(in);

}
Process* MultiQueue::dequeue(int level)
{
    return queues[level-1].dequeue();
}

bool MultiQueue::isEmpty()
{   
    bool ret = true;
    for(int i=0;i<3;i++)
    {
        ret = ret && queues[i].isEmpty();
    }
    return ret;
}

Process* MultiQueue::front(int q)
{
    return queues[q].head;
}