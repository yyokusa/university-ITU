#include <stdio.h>
#include <iostream>

using namespace std;

int sayac=0;

void infinite()
{
	cout<<"stack segment is being filled"<<endl;
	infinite();
}

int main()
{
  infinite(); // recursion without base case
}
