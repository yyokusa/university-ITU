typedef int QueueDataType;
struct  Node
{
	QueueDataType data;
	Node *next;
};

