#pragma once

void test_traversals();
void test_bst();
void test_bfs();
