#define TOKEN_LENGTH 3

struct Token{
	char token[TOKEN_LENGTH];	
	int count=0;
};
