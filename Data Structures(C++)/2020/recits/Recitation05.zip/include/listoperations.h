#ifndef LISTOPERATIONS_H
#define LISTOPERATIONS_H
#include <stdio.h>

#include "record.h"

struct List{
	char filename[20];
	Phone_Record * head; 
	Phone_Record * index[26]; //week5
	int records_count=0;
	FILE *phonebook;
	void makeEmpty();
	void printList();
	void create();
	void close();
	void add(Phone_Record *);
	int search(char []);
	void remove(int recordnum);
	void update(int recordnum, Phone_Record *);
};
#endif
