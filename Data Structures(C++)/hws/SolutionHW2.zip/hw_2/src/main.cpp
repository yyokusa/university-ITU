#include<fstream>
#include<stdio.h>
#include<iostream>
#include<stdlib.h>
#include<tgmath.h>

#include "circuit.h"
#include "unique_circuit.h"

using namespace std;

circuit list;
unique_circuit list_2;

int main(int argc, char* argv[])
{
    //const char* filename = "input.txt";
    const char* filename = argv[1];
    double value;
    char group;

    int  is_resistor;

    ifstream file(filename);

    if(!file)
    {
        cerr << "Cannot open file" << endl;
        return EXIT_FAILURE;
    }

    list.create();

    while(file>>group)
    {
        //cout << group << endl;
        if(file>>value)
        {
            //cout << value << endl;
            if(value > 0)
                list.add_resistor(group,value);
            else if(value < 0)
            {
                is_resistor = list.remove_resistor(group, -value);
                if(is_resistor == 0) cout << "NO_RESISTOR" << endl;
            }
            else if(group == 'A' && value == 0)
                list_2.list(&list);
        }

    }
    system("pause");  
    return EXIT_SUCCESS;

}

    //void create();
    //void add_resistor(char,double);
    //int remove_resistor(char,double);
    //void delete_resistor(char);
    //void circuit_info();
    //void clear();

void circuit::create()
{
    head = NULL;
}

void circuit::add_resistor(char group, double value)
{
    resistor *traverse, *previous;
    traverse = head;

    while (traverse) //To increase quantity
    {
        if(traverse->group == group && traverse->value == value)
        {
            traverse->quantity++;
            return;
        }
            
        traverse = traverse->next;
    }

    traverse = head;

    resistor* node = new resistor;
    node->group = group;
    node->value = value;
    node->quantity = 1;
    node->next = NULL;

    if(!traverse) //first node adding
    {
        
        head = node;
        list_2.add(value);
        return;

    }

    if(traverse && (int(group) < int(traverse->group))) // new node is placed instead of head
    {
        node->next = head;
        head = node;
        list_2.add(value);
        return;
    }

    while (traverse && (int)traverse->group < (int)group) //traversing
    {
        previous = traverse;
        traverse= traverse->next;
    }

    if(traverse) // add into the mid position
    {
        node->next = traverse;
        previous->next =node; 
        list_2.add(value);
    }
    
    else //add to the end
    {
        previous->next = node;
        list_2.add(value);
    }


}

void unique_circuit::add(double value)
{
     
    unique *traverse, *previous;
    traverse = head;

    

    while (traverse) //if the value is not unique, do not add.
    {
        if(traverse->value == value)
            return;
            
        traverse = traverse->next;
    }

    traverse = head;

    unique* node = new unique;
    node->value = value;
    node->next = NULL;

    if(!traverse) //first node adding
    {
        head = node;
        return;
    }

    if(traverse && (value < traverse->value)) // new node is placed instead of head
    {
        node->next = head;
        head = node;
        return;
    }

    while (traverse && traverse->value < value) //traversing
    {
        previous = traverse;
        traverse= traverse->next;
    }

    if(traverse) // add into the mid position
    {
        node->next = traverse;
        previous->next =node; 
    }
    
    else //add to the end
    {
        previous->next = node;
    }
    
    
}
 
int circuit::remove_resistor(char group, double value)
{
    
    resistor *traverse = head;
    int resistor_count = 0;

    while(traverse)
    {
        if(traverse->value == value && traverse->group == group && traverse->quantity>1) //if quantity >0 then decrease quantity
            {
                traverse->quantity--;
                return 1;
            }
        traverse = traverse->next;
    }

    traverse = head;
    bool is_resistor = false;

    while(traverse)
    {
        if(traverse->value == value && traverse->group == group)
            is_resistor = true;
        
        if(traverse->value == value)
            resistor_count ++;
        
        traverse = traverse->next;
    }

    if(!is_resistor) //NO_RESISTOR
        return 0;

    
    delete_resistor(group, resistor_count, value);
    return 1;
    
}

void circuit::delete_resistor(char group, int resistor_count, double value)
{
    resistor *traverse = head;
    resistor *previous;

    if((traverse->group == group) && (traverse->value == value)) // deleting the head
    {
        head = head->next;
        if(resistor_count == 1) list_2.remove(traverse->value);
        delete traverse;
        return;
    }
     
    previous = traverse;
    traverse = traverse->next;
    while(traverse)
    {
        if((traverse->group == group) && (traverse->value == value)) // deleting nodes except the head
        {
            previous->next = traverse->next;
            if(resistor_count == 1) list_2.remove(traverse->value);
            delete traverse;
            return;
        }
        previous = traverse;
        traverse = traverse->next;
    }
}

void unique_circuit::remove(double value)
{
    unique *traverse = head;
    unique *previous;

    if(traverse->value == value) // deleting the head
    {
        head = head->next;
        delete traverse;
        return;
    }
     
    previous = traverse;
    traverse = traverse->next;
    while(traverse)
    {
        if(traverse->value == value) // deleting nodes except the head
        {
            previous->next = traverse->next;
            delete traverse;
            return;
        }
        
        previous = traverse;
        traverse = traverse->next;
    }
}


void unique_circuit::list(circuit *l1)
{
    unique *traverse_1 = head;
    resistor *traverse_2 = l1->head;
    int resistor_count;
    double total_resistance = 0;
    double res;
    int i;

    //total resistance calculation:
    while (traverse_2)
    {
        if(traverse_2->quantity > 1)
        {
            res = 0;

            for(i=0;i<traverse_2->quantity;i++)
                res+=pow(traverse_2->value,-1);

            total_resistance += pow(res,-1);
        }
        else
            total_resistance += traverse_2->value;

        traverse_2 = traverse_2->next;
                
    }
    

    while(traverse_1)
    {
        traverse_2 = l1->head;
        resistor_count = 0;
        while(traverse_2)
        {
            if(traverse_2->value == traverse_1->value)
                resistor_count += traverse_2->quantity;
           
            traverse_2 = traverse_2->next;
        }   
        cout << traverse_1->value << ":" << resistor_count << endl;
        traverse_1 = traverse_1->next;
    }

    cout << "Total resistance=" << total_resistance << " ohm" << endl;

}
