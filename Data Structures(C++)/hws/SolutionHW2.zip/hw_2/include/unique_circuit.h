#include "unique.h"
struct unique_circuit
{
    unique *head;
    void add(double);
    void remove(double);
    void list(circuit*);
    void clear();
};