#include "resistor.h"
struct circuit
{
    resistor *head;
    void create();
    void add_resistor(char,double);
    int remove_resistor(char,double);
    void delete_resistor(char, int, double);
    void circuit_info();
    void clear();
};