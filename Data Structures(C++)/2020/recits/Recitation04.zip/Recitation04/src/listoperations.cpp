#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "listoperations.h"

using namespace std;

void List::add(Phone_Record *nrptr){
	Phone_Record *node = new Phone_Record;
	strcpy(node->name,nrptr->name);
	strcpy(node->phonenum,nrptr->phonenum);
	node->next=NULL;

	// add the new node to convenient where in linked list
	Phone_Record *traverse, *previous;
	traverse=head;
	if (!traverse){ // first node adding
		head=node;
		records_count++;
		printList();
		return;
	}
	int i=0; // to check whetherit comes before head or not
	while (traverse&&strncasecmp(traverse->name,node->name,strlen(node->name))<0)
	{
		previous=traverse;
		traverse=traverse->next;
		i++;
	}
	if(i==0) // new node is placed instead of head
	{
		node->next=head;
		head=node;
	}	
	else if(traverse) // add into the mid position
	{
		node->next=traverse;    // p n t
		previous->next=node;
	}
	else // add to the end of the list
	{
		previous->next=node;  	// p n
	}
	records_count++;
	printList();
}


void List::create(){
	head=NULL;
	records_count=0;	
	Phone_Record node;

	struct File_Record
	{
		char name[NAME_LENGTH];
		char phonenum[PHONENUM_LENGTH];
	};
	File_Record k;	

	strcpy(filename,"phonebook.txt");
	phonebook = fopen( filename, "r+" );
	if(!phonebook){ // Dosya bulunamad�, bu nedenle bo� olarak olu�tur.		
		if(!(phonebook = fopen( filename, "w+" ))){
			cerr << "Cannot open file" << endl;
			exit(1);
		}
	}
	else{
		fseek(phonebook,0,SEEK_SET);
		while(fread(&k,sizeof(File_Record),1,phonebook)){
			strcpy(node.name,k.name);
			strcpy(node.phonenum,k.phonenum);
			node.next=NULL;
			add(&node);			
		}
	}
	fclose(phonebook);
}

void List::close(){
	if(!(phonebook=fopen(filename,"w"))){
		cerr << "Cannot open file" << endl;
		exit(1);
	}
		struct File_Record
	{
		char name[NAME_LENGTH];
		char phonenum[PHONENUM_LENGTH];
	};
	File_Record k;	

	Phone_Record *traverse=head;
	while (traverse)
	{
		strcpy(k.name,traverse->name);
		strcpy(k.phonenum,traverse->phonenum);
		fwrite(&k,sizeof(File_Record),1,phonebook);
		traverse=traverse->next;
	}		
	fclose(phonebook);
	makeEmpty();
}

void List::makeEmpty()
{
	Phone_Record *traverse;
	while (head)   // D 
	{
		traverse=head;
		head=head->next;
		delete traverse;
	}
	records_count=0;
}

void List::printList()
{
	Phone_Record *traverse=head;
	cout<<endl<<"CURRENT VERSION OF LINKED LIST"<<endl;
	for (int i=1;traverse;i++,traverse=traverse->next)
		cout<<i<<". "<<traverse->name<<" "<<traverse->phonenum<<endl;
	cout<<endl;
}

int List::search(char *desired){
	bool all=false;
	int found=0;
	if(strcmp(desired,"*")==0)  //Compares the string str1 to the string str2. (http://www.cplusplus.com/reference/cstring/strcmp/?kw=strcmp)
		all=true;
	
	Phone_Record *traverse=head;
	for(int i=1;i<=records_count;i++, traverse=traverse->next){
		if(!all && strncasecmp(traverse->name, desired, strlen(desired))!=0) //compares, at most, the first n characters of string1 and string2 without sensitivity to case.
			continue; // A�a��daki komutlar� atla, while'� s�rd�r.
		cout << i << "." << traverse->name << " " << traverse->phonenum << endl;
		found++;	
	}	
	return found;
}

void List::update(int recordnum, Phone_Record *nrptr){
    remove(recordnum);
	add(nrptr);
}

void List::remove(int recordnum){
	if (recordnum <=records_count && recordnum>0)
	{
		Phone_Record *traverse=head;
		Phone_Record *previous;
		for(int i=1;i<=records_count;i++, traverse=traverse->next)
		{
			if (i==recordnum)
			{
				if (i==1) // deleting the head
					head=head->next;
				else // deleting nodes except the head
				{
					previous->next=traverse->next; 
				}
				delete traverse;
				break;				
			}
			previous=traverse;
		}
		records_count--;
	}
	else
	{
		cout<<"Could not find record to delete."<<endl;
	}
	
}
